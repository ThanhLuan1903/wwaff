<div class="_3vMlZCRTDMcko6fQUVb1Uf css-1qvl0ud css-y2hsyn tabcontent changepass">
  <form class="sc-kVrTmx dLApJx">
    <div class="_3WCfA5WYRlXEJAXoSGLCJM css-1775qrv">
      <span class="_2emChIs6yt79MK9bxuriDh">Current password*</span>
      <input placeholder="Current password*" name="oldpassword" type="password" class="_1Yox25pgA6Bt9-R0uIDpcS _2U8LClDsGTjhEIQtswl0q7 _2WJImvbnE8I3_hccXYSMQ css-4s204c" value="">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="_2ZTo9--SzlVupN_LAvBNdo css-gyuu5p">
        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
      </svg>
    </div>
    <div class="_3WCfA5WYRlXEJAXoSGLCJM css-1775qrv">
      <span class="_2emChIs6yt79MK9bxuriDh">New password*</span>
      <input placeholder="New password*" name="newpassword" type="password" class="_1Yox25pgA6Bt9-R0uIDpcS _2U8LClDsGTjhEIQtswl0q7 _2WJImvbnE8I3_hccXYSMQ css-4s204c" value="">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="_2ZTo9--SzlVupN_LAvBNdo css-gyuu5p">
        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
      </svg>
    </div>
    <p class="sc-ekkqgF hrBkWD">Password must contain: 8 or up to 30 characters with at least one uppercase, at least one lowercase, at least one numeric digit, at least one of the allowed special characters listed: _-!@*.$%?&amp;#/|\&gt;^{}[]():;</p>
    <!-- <div class="_3WCfA5WYRlXEJAXoSGLCJM css-1775qrv">
      <span class="_2emChIs6yt79MK9bxuriDh">Repeat password*</span>
      <input placeholder="Repeat password*" name="confirmpassword" type="password" class="_1Yox25pgA6Bt9-R0uIDpcS _2U8LClDsGTjhEIQtswl0q7 _2WJImvbnE8I3_hccXYSMQ css-4s204c" value="">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="_2ZTo9--SzlVupN_LAvBNdo css-gyuu5p">
        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
      </svg>
    </div> -->
    <input type="hidden" name="action" value="Update Password">
    <div class="sc-iBmynh cvPOSD">
      <button class="data_save K3TX2EnGEDIGIEiEIo_0X _3-Xcfgk4YnBeM0kgvmZfs_">
        <div class="_3kiCWIsiMrRqCXneU8Asq6" style="height: 0px; width: 0px; left: 0px; top: 0px;"></div>
        <span class="_1pFgCebzxXEI3gItBe_863">
          <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="">
            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
          </svg>
        </span>
        <span class="_3axrJUuPR6Tfk-J1aQF4dm">Save</span>
      </button>
    </div>
  </form>
</div>