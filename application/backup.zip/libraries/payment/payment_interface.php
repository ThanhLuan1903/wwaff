<?php

interface PaymentInteface
{
  public function send_payment($form);
}
