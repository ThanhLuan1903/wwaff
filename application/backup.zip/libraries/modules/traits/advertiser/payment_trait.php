<?php

require_once APPPATH . 'libraries/payment/payment_plugin.php';

trait Advertiser_PaymentTrait
{

  public function payment_list()
  {
    $payments =  $this->db->where('adv_id', $this->session->userdata('user')->id)->get('advertiser_payment')->result();
    $need_payment = $this->Advertiser_model->check_arrive_paymterm($this->session->userdata('user')->id);
    $available = $this->Advertiser_model->need_payment_amount($this->session->userdata('user')->id);

    $content = $this->load->view('advertiser/payment/form', compact('payments', 'need_payment', 'available'), true);
    return $this->load->view('advertiser/default/vindex', compact('content'));
  }

  public function request_payouts()
  {
    if (!$this->is_method_post()) {
        throw new Exception('Method is not supported');
    }

    $id = $this->input->post('pid');

    $tracklinkIdList = $this->input->post('tracklinkIdList');    
    if (!empty($tracklinkIdList)) {
        $tracklinkIds = explode(',', $tracklinkIdList); // Chuyển chuỗi thành mảng
        // Thực hiện xử lý với $tracklinkIds
        $this->db->where_in('id', $tracklinkIds);
        $this->db->update('tracklink', ['adv_pay' => 1]);
    }
    // Cấu hình upload hình ảnh
    $config['upload_path'] = './upload/payment_images/';
    $config['allowed_types'] = 'jpg|jpeg|png|gif';
    $config['max_size'] = 2048; // 2MB
    $config['encrypt_name'] = true; // Tạo tên file ngẫu nhiên để tránh trùng lặp

    $this->load->library('upload', $config);

    $imagePath = null;

    // Kiểm tra nếu có file được upload
    if (!empty($_FILES['payment_image']['name'])) {
        if (!$this->upload->do_upload('payment_image')) {
            // Nếu upload thất bại, trả về lỗi
            $error = $this->upload->display_errors();
            throw new Exception('Image upload failed: ' . $error);
        } else {
            // Nếu upload thành công, lấy đường dẫn file
            $uploadData = $this->upload->data();
            $imagePath = 'uploads/payment_images/' . $uploadData['file_name'];
        }
    }

    if ($id) {
        // Cập nhật thông tin thanh toán nếu đã tồn tại
        $payment = $this->db->where('id', $id);
        $updateData = [
            'note' => $this->input->post('note')
        ];

        if ($imagePath) {
            $updateData['image_path'] = $imagePath; // Cập nhật đường dẫn hình ảnh nếu có
        }

        $payment->update('advertiser_payment', $updateData);
    } else {
        // Tạo mới thông tin thanh toán
        $data = [
            'amount' => $this->input->post('amount'),
            'note' => $this->input->post('note'),
            'method' => $this->input->post('method'),
            'adv_id' => $this->session->userdata('user')->id,
            'image_path' => $imagePath, // Lưu đường dẫn hình ảnh nếu có
        ];

        $this->db->insert('advertiser_payment', $data);
    }

    return redirect(base_url('v2/payments'));
  }
}
