<?php

trait Publisher_PaymentTrait
{
  public function payment_list()
  {
    $this->db->where('usersid', $this->member->id);
    $data['payment'] = $this->db->order_by('id', 'DESC')->get('invoice')->result();
    $content = $this->load->view('payments/listpm.php', $data, true);
    $this->load->view('default/vindex.php', array('content' => $content));
  }

  public function request_payouts()
  {
    //check min pay va balance        
    $point = floatval($this->input->post('amount'));
    $pmethod = $this->input->post('payment_method');
    $paymentId = (int)$this->input->post('pid');
    $note = '';
    if ($pmethod == "pmchose") {
      $this->session->set_userdata('err_po', 'Please select a payment method!');
      goto ketthuc;
    } elseif ($pmethod == 'PayPal') {
      $note = $this->input->post('payment_paypal_email');
    } elseif ($pmethod == 'Payoneer') {
      $note = $this->input->post('payment_payoneer_email');
    } elseif ($pmethod == 'Crypto') {
      $note = $this->input->post('payment_Crypto');
    } elseif ($pmethod == 'Bank Wire') {
      $BankWire = $this->input->post('BankWire');
      $note = serialize($BankWire);
    }

    $uid = $this->member->id;
    $date = date("Y-m-d H:i:s");
    if ($uid) {
      if ($point > floatval($this->member->available)) $point = floatval($this->member->available);
      if ($paymentId) { //sửa thông tin
        //check xem no postd đúng user k
        $this->db->where(array('id' => $paymentId, 'usersid' => $uid));
        $this->db->update('invoice', array('note' => $note, 'method' => $pmethod));
        if ($this->db->affected_rows() > 0) {
          $this->session->set_userdata('succ_po', 'Updated!');
        } else {
          $this->session->set_userdata('err_po', 'Error!');
        }
      } else {
        //kiểm tra minpay
        if (floatval($this->pub_config['minpay']) > floatval($this->member->available)) {
          redirect(base_url('v2/payments'));
          return;
        }
        //$this->db->trans_start();
        $this->db->where('id', $uid);
        $this->db->set('available', "available - $point", FALSE);
        $this->db->set('pending', "pending + $point", FALSE);
        $this->db->set('log', "invoice: $date - $point");
        $this->db->update('users');
        if ($this->db->affected_rows() > 0) {
          $this->db->insert('invoice', array(
            'status' => 'Pending',
            'amount' => $point,
            'method' => $pmethod,
            'note' => $note,
            'usersid' => $uid,
            'date' => $date,
            'type' => 3
          ));
        }
        //$this->db->trans_complete();
      }
    }
    //$this->session->set_userdata('err_po','The amount is not null!');


    ketthuc:
    redirect(base_url('v2/payments'));
  }
}
