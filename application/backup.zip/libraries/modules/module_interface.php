<?php

interface ModuleInterface {
  function dashboard();
  function profile();
  function referrals();
}