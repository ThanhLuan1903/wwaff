<?php

interface Notification_Observer
{
   public function notify();
}
