<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-04-24 04:20:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:16 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\wwaff\application\views\admin\content\tracklink_list.php 33
ERROR - 2025-04-24 04:20:16 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 04:20:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 04:20:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:34 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\wwaff\application\views\admin\content\tracklink_list.php 33
ERROR - 2025-04-24 04:20:34 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 04:20:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 04:20:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:46 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\wwaff\application\views\admin\content\tracklink_list.php 33
ERROR - 2025-04-24 04:20:46 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 04:20:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 04:20:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:20:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:21:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:21:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:21:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:21:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:21:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:21:07 --> Severity: Notice  --> Undefined property: stdClass::$chatuser C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-24 04:21:07 --> Severity: Notice  --> Undefined property: stdClass::$balance C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-24 04:21:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:21:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:21:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 93 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 98 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 81 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-24 04:21:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 66 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-24 04:21:12 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 04:28:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:28:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:28:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:28:41 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 04:32:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:32:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:32:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 04:32:08 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 05:31:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:31:38 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 273
ERROR - 2025-04-24 05:31:38 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 281
ERROR - 2025-04-24 05:31:38 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:31:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:31:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:31:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:31:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:32:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:32:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:32:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:33:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:33:05 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 273
ERROR - 2025-04-24 05:33:05 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 281
ERROR - 2025-04-24 05:33:05 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:33:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:33:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:33:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:33:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:33:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:33:17 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 273
ERROR - 2025-04-24 05:33:17 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 281
ERROR - 2025-04-24 05:33:17 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:33:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:33:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:33:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:33:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:34:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:34:07 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:34:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:34:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:34:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:34:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:35:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:35:05 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:35:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:35:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:35:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:35:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:35:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:35:16 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\admin\content\network_list.php 96
ERROR - 2025-04-24 05:35:16 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:35:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:35:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:35:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:35:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:35:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:35:30 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 273
ERROR - 2025-04-24 05:35:30 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 281
ERROR - 2025-04-24 05:35:30 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:35:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:35:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:35:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:35:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:37:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:37:14 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 273
ERROR - 2025-04-24 05:37:14 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 281
ERROR - 2025-04-24 05:37:14 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:37:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:37:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:37:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:37:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:37:24 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 273
ERROR - 2025-04-24 05:37:24 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 281
ERROR - 2025-04-24 05:37:24 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:37:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:37:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:37:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:38:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:38:01 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 273
ERROR - 2025-04-24 05:38:01 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 281
ERROR - 2025-04-24 05:38:01 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:38:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:38:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:38:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:38:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:38:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:38:10 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 273
ERROR - 2025-04-24 05:38:10 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 281
ERROR - 2025-04-24 05:38:10 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:38:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-24 05:38:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:38:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:38:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:38:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:38:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:38:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:38:54 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 05:39:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:39:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:39:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:39:51 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 05:40:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:40:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:40:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:40:08 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 05:40:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:40:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:40:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:40:46 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 05:41:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:41:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:41:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:41:51 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 05:42:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:42:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:42:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:42:10 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 05:43:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:43:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:43:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:44:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:44:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:44:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:44:28 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 05:44:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:44:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:44:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:44:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:44:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:44:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:44:47 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 05:44:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:44:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:44:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:45:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:45:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:45:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:45:31 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 05:45:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:45:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:45:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:45:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:45:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:45:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:45:46 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 05:45:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:45:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:45:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:47:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:47:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:47:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:47:01 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 05:47:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:47:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:47:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:47:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:47:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:47:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:47:23 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-24 05:47:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:47:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-24 05:47:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
