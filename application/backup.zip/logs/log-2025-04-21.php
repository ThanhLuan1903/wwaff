ERROR - 2025-04-21 21:11:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:11:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:11:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:12:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:12:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:12:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:12:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:12:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:12:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:13:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:13:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:13:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:13:22 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-21 21:14:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:14:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:14:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:14:12 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-21 21:16:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:16:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:16:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:18:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:18:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:18:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:18:45 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-21 21:18:45 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-21 21:18:45 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-21 21:18:45 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-21 21:18:45 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-21 21:18:45 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-21 21:18:45 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-21 21:18:45 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-21 21:18:45 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-21 21:18:45 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-21 21:18:45 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-21 21:18:45 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-21 21:18:45 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\wwaff\application\modules\members\views\offers\list_offers.php 285
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 20 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 23 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 33 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-21 21:18:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:18:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:18:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 26 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 21 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 30 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 28 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:56 --> Severity: Notice  --> unserialize(): Error at offset 14 of 18 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-21 21:18:56 --> Severity: Notice  --> unserialize(): Error at offset 14 of 18 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-21 21:18:56 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:56 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:56 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:56 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:56 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:18:56 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:18:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:19:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:19:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 264
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-21 21:19:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:19:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:19:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:19:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:19:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:19:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-21 21:19:17 --> Severity: Notice  --> Undefined index: left C:\xampp\htdocs\wwaff\application\libraries\modules\traits\advertiser\product_trait.php 210
ERROR - 2025-04-21 21:19:17 --> Severity: Notice  --> Undefined index: right C:\xampp\htdocs\wwaff\application\libraries\modules\traits\advertiser\product_trait.php 211
ERROR - 2025-04-21 21:19:17 --> Severity: 4096  --> Argument 1 passed to Advertiser_model::sort_options() must be an instance of string, boolean given, called in C:\xampp\htdocs\wwaff\application\models\advertiser_model.php on line 369 and defined C:\xampp\htdocs\wwaff\application\models\advertiser_model.php 111
ERROR - 2025-04-21 21:19:17 --> Severity: Notice  --> Undefined property: Advertiser::$per_page C:\xampp\htdocs\wwaff\application\libraries\modules\traits\advertiser\product_trait.php 216
ERROR - 2025-04-21 21:19:17 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\libraries\modules\traits\advertiser\product_trait.php 216
