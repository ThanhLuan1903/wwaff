<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-04-23 04:21:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:26 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\wwaff\application\views\admin\content\tracklink_list.php 33
ERROR - 2025-04-23 04:21:26 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:21:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:21:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:21:49 --> Severity: Notice  --> Undefined property: stdClass::$chatuser C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-23 04:21:49 --> Severity: Notice  --> Undefined property: stdClass::$balance C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-23 04:22:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:22:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:22:36 --> Severity: Notice  --> Undefined property: stdClass::$chatuser C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-23 04:22:36 --> Severity: Notice  --> Undefined property: stdClass::$balance C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-23 04:22:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:22:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:22:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 04:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 93 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 98 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 81 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 66 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 04:22:40 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 04:23:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:27 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\wwaff\application\views\admin\content\tracklink_list.php 33
ERROR - 2025-04-23 04:23:27 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:23:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:23:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:35 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\views\admin\content\users_list.php 144
ERROR - 2025-04-23 04:23:35 --> Severity: Notice  --> Undefined index: im_service C:\xampp\htdocs\wwaff\application\views\admin\content\users_list.php 145
ERROR - 2025-04-23 04:23:35 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\views\admin\content\users_list.php 144
ERROR - 2025-04-23 04:23:35 --> Severity: Notice  --> Undefined index: im_service C:\xampp\htdocs\wwaff\application\views\admin\content\users_list.php 145
ERROR - 2025-04-23 04:23:35 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:23:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:23:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:46 --> Severity: Notice  --> Undefined property: stdClass::$mailling C:\xampp\htdocs\wwaff\application\views\default\topbar.php 1
ERROR - 2025-04-23 04:23:46 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-23 04:23:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:23:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:23:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:23:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:23:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:23:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:23:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:23:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:23:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:23:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:23:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:23:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:23:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:23:53 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:23:53 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 04:23:53 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 04:23:53 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 04:23:53 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 04:30:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:30:05 --> Severity: Notice  --> Undefined property: stdClass::$mailling C:\xampp\htdocs\wwaff\application\views\default\topbar.php 1
ERROR - 2025-04-23 04:30:05 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-23 04:30:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:31:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:31:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:31:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:31:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:31:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:31:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 20 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 23 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 33 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 26 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 21 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 30 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 28 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 20 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 23 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 33 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 26 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 21 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 30 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 28 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:31:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:31:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:31:53 --> Severity: Notice  --> Undefined property: Statistics::$is_adv C:\xampp\htdocs\wwaff\application\modules\members\controllers\statistics.php 26
ERROR - 2025-04-23 04:31:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `cpalead_users`.`id` =  '2592'' at line 4
ERROR - 2025-04-23 04:32:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:33:02 --> Severity: Notice  --> Undefined property: Statistics::$is_adv C:\xampp\htdocs\wwaff\application\modules\members\controllers\statistics.php 26
ERROR - 2025-04-23 04:35:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `cpalead_users`.`id` =  '2592'' at line 4
ERROR - 2025-04-23 04:36:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:36:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:36:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:36:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:36:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:36:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:36:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:36:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:36:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:36:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:03 --> Query error: Unknown column 'D' in 'order clause'
ERROR - 2025-04-23 04:37:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:11 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\wwaff\application\views\admin\content\tracklink_list.php 33
ERROR - 2025-04-23 04:37:11 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:37:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:37:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:13 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\admin\content\network_list.php 96
ERROR - 2025-04-23 04:37:13 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:37:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:37:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:15 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\views\admin\content\users_list.php 144
ERROR - 2025-04-23 04:37:15 --> Severity: Notice  --> Undefined index: im_service C:\xampp\htdocs\wwaff\application\views\admin\content\users_list.php 145
ERROR - 2025-04-23 04:37:15 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\views\admin\content\users_list.php 144
ERROR - 2025-04-23 04:37:15 --> Severity: Notice  --> Undefined index: im_service C:\xampp\htdocs\wwaff\application\views\admin\content\users_list.php 145
ERROR - 2025-04-23 04:37:15 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:37:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:37:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 20 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 23 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 33 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 26 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 21 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 30 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 28 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 20 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 23 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 33 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 26 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 21 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 30 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 28 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:26 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:37:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 20 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 23 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 33 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 26 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 21 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 30 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 28 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 20 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 23 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 33 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 26 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 21 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 30 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 28 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:37:37 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:37:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:37:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:38:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:38:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:38:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 20 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 23 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 33 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 26 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 21 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 30 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 28 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:05 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 20 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 23 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 33 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 26 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 21 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 30 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 28 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:38:06 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:38:17 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:39:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:39:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:39:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:39:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:39:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:39:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:39:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:39:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:40:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:40:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:40:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 14
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 15
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 16
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 17
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 21
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 50
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 2
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 4
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved1.php 7
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 140
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 143
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 144
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 146
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 173
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 179
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 193
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 194
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 218
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 228
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 239
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 29
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\approved2.php 36
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 20 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 23 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 33 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 26 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 21 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 30 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 28 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 20 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 23 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 33 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:54 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 26 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 21 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 30 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 28 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:40:55 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:41:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:41:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:41:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:41:35 --> Severity: Notice  --> Undefined property: CI_Session::$set_userdata C:\xampp\htdocs\wwaff\application\libraries\auth\auth_plugin.php 34
ERROR - 2025-04-23 04:42:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:42:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:42:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:42:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:42:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:42:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:42:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:42:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:42:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:42:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:42:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:42:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:42:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:42:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:42:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:42:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\wwaff\application\modules\members\views\offers\list_offers.php 285
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 20 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 23 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 33 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 24 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:42:32 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:42:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:42:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:42:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:43:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:43:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:43:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:43:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:43:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:43:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:43:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:43:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:43:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:43:48 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:43:48 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:43:48 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:43:48 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:43:48 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:43:48 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:43:48 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:43:48 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:43:48 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:43:48 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:43:48 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:43:48 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:43:48 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:43:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:44:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:44:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:44:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:05 --> Severity: Notice  --> Undefined variable: right_title C:\xampp\htdocs\wwaff\application\modules\members\views\offers\list_offers.php 412
ERROR - 2025-04-23 04:44:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\list_offers.php 412
ERROR - 2025-04-23 04:44:05 --> Severity: Notice  --> Undefined variable: right_title C:\xampp\htdocs\wwaff\application\modules\members\views\offers\list_offers.php 413
ERROR - 2025-04-23 04:44:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\list_offers.php 413
ERROR - 2025-04-23 04:44:05 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:44:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:44:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:44:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:44:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:44:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:44:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:44:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:44:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:44:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:44:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 26 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\ajax\lazy_offers.php 39
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 21 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 32 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:56 --> Severity: Notice  --> unserialize(): Error at offset 0 of 25 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 30 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 28 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 29 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> unserialize(): Error at offset 0 of 34 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> unserialize(): Error at offset 14 of 18 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 27
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> unserialize(): Error at offset 14 of 18 bytes C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 28
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:44:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:45:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:36 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:45:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:45:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:43 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:43 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:43 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:43 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:43 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:43 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:43 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:43 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:43 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:43 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:43 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:45:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:51 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:51 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:51 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:51 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:51 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:51 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:51 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:51 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:45:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:45:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:45:56 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:56 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:56 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:56 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:56 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:56 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:56 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:56 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:56 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:56 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:45:56 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:45:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:45:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 04:46:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:46:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:46:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:46:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:46:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:46:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:46:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:46:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:46:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:46:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 04:46:24 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:46:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:46:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:29 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:46:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:31 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:46:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:46:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:46:49 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:46:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:46:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:46:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:21 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:48:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:48:33 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:48:33 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:48:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:47 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:48:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 04:48:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:48:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:49:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:49:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:49:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:50:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:50:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:50:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:50:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:50:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:50:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:50:47 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:50:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:50:47 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:50:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:50:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:50:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:50:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:50:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:50:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:04 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:51:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:51:04 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:51:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\members\views\offers\filters\option_search.php 57
ERROR - 2025-04-23 04:51:24 --> Severity: Notice  --> Undefined variable: publisher C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\views\offers\campaign_view.php 279
ERROR - 2025-04-23 04:51:24 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:51:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:51:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:53:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:53:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:53:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:53:39 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:53:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:53:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:53:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:53:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:53:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:53:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:53:53 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 04:53:53 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 04:53:53 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 04:53:53 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 04:55:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:55:43 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:55:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:55:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:55:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:13 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:57:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:20 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 04:57:20 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 04:57:20 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 04:57:20 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 04:57:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:27 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 04:57:27 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 04:57:27 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 04:57:27 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 04:57:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:31 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 04:57:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:57:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:58:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:58:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:58:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:58:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:58:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:58:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:58:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:58:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:58:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:58:21 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 04:58:21 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 04:58:21 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 04:58:21 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 04:58:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:58:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:58:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:59:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:59:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:59:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:59:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:59:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:59:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:59:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:59:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:59:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:59:11 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 04:59:11 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 04:59:11 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 04:59:11 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 04:59:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:59:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 04:59:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:00:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:00:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:00:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:00:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:00:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:00:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:00:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:00:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:00:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:00:05 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 05:00:05 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 05:00:05 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 05:00:05 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:00:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:00:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:00:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:01:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:01:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:01:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:01:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:01:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:01:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:01:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:01:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:01:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:01:16 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 05:01:16 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 05:01:16 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 05:01:16 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:01:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:01:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:01:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:02:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:02:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:02:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:02:22 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 05:02:22 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 05:02:22 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 05:02:23 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:02:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:02:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:02:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:30 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 05:05:30 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 05:05:30 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 05:05:30 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:05:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:46 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 05:05:46 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 05:05:46 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 05:05:46 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:05:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:05:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:07:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:07:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:07:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:07:07 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 05:07:07 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 05:07:07 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 05:07:07 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:07:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:07:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:07:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:07:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:07:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:07:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:07:34 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 05:07:34 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 05:07:34 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 05:07:34 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:07:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:07:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:07:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:08:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:08:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:08:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:08:51 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 05:08:51 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 05:08:51 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 05:08:51 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:08:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:08:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:08:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:08:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:08:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:08:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:08:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:08:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:08:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:09:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:09:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:09:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:09:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:09:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:09:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:10:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:10:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:10:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:22 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 05:11:22 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 05:11:22 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 05:11:22 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:11:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:33 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 05:11:33 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 05:11:33 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 05:11:33 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:11:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:54 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 05:11:54 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 05:11:54 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 05:11:54 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:11:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:11:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:12:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:12:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 05:12:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:12:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:12:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:12:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:12:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 05:12:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:12:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:12:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:12:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:12:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:12:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:12:52 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 05:12:52 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 05:12:52 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 05:12:52 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:12:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:12:58 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-23 05:16:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:16:58 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 05:17:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:17:29 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 05:19:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:19:23 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-23 05:19:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:19:35 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 05:20:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:20:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:20:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:20:06 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:21:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:21:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:21:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:21:51 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:22:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:22:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:22:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:25:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:25:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:25:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:25:37 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:25:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:25:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:25:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:27:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:27:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:27:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> unserialize(): Error at offset 0 of 93 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:27:08 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:08 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:27:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:27:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:27:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:27:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:27:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:27:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 98 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:27:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:27:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 81 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:27:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:27:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:27:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 66 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:09 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:27:09 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:27:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:27:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:27:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:27:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:27:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:27:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:27:47 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:27:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:27:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:27:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:30:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:30:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:30:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:30:34 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:30:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:30:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:30:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:07 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:32:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:20 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:32:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:43 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:32:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:32:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:09 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:33:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:22 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:33:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:46 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:33:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:59 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:33:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:33:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:34:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:34:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:34:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:34:25 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:34:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:34:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:34:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:35:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:35:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:35:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:35:37 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:35:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:35:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:35:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:37:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:37:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:37:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:37:25 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:37:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:37:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:37:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:37:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:37:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:37:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:37:36 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:37:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:37:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:37:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:40:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:40:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:40:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:40:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 05:42:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:42:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:42:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:42:32 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 05:42:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:42:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wwaff\application\views\default\vindex.php 190
ERROR - 2025-04-23 05:42:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:42:44 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-23 05:47:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:47:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:47:48 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\wwaff\application\views\admin\content\tracklink_list.php 33
ERROR - 2025-04-23 05:47:48 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:47:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:47:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:47:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:47:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:06 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:10 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:12 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:48:19 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:48:19 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:48:19 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:48:19 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:48:19 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:48:19 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:48:19 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:48:19 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:48:19 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:48:19 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:48:19 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:23 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:56 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:59 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:48:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:48:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:49:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:49:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\content\offer_edit.php 213
ERROR - 2025-04-23 05:49:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\content\offer_edit.php 214
ERROR - 2025-04-23 05:49:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\content\offer_edit.php 277
ERROR - 2025-04-23 05:49:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\content\offer_edit.php 325
ERROR - 2025-04-23 05:49:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\content\offer_edit.php 336
ERROR - 2025-04-23 05:49:01 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:49:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:49:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:49:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:49:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:49:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:49:05 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:49:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:49:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:49:15 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:49:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:49:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:49:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:49:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:14 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:14 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:14 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:14 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:14 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:14 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:15 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:15 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:15 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:15 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:15 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:50:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:50:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:22 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:50:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:50:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:24 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:50:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:28 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:28 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:28 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:28 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:28 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:28 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:28 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:28 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:28 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:28 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:28 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:50:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:50:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Warning  --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 13
ERROR - 2025-04-23 05:50:34 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:34 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:34 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:34 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:34 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:34 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:34 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:34 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:34 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:34 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wwaff\application\modules\adm_adc\views\advertiser_management\products.php 62
ERROR - 2025-04-23 05:50:34 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:50:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 05:50:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:50:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:55:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:55:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:55:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 05:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 93 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 98 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 81 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> unserialize(): Error at offset 0 of 66 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 05:55:31 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 05:55:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:55:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:55:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 05:55:33 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 06:00:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 06:00:20 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-23 06:02:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 06:02:59 --> Severity: Notice  --> Undefined property: stdClass::$tapp C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\offers.php 78
ERROR - 2025-04-23 06:02:59 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-23 06:03:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 06:03:00 --> Severity: Notice  --> Undefined property: stdClass::$tapp C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\offers.php 78
ERROR - 2025-04-23 06:03:00 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-23 06:05:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 06:05:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 06:05:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 06:05:08 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 06:05:08 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 06:05:08 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 06:05:08 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 06:08:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 06:08:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '//pedning        
        SUM(CASE WHEN cpalead_tracklink.status=2 THEN 1 ELSE ' at line 4
ERROR - 2025-04-23 06:09:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 06:09:15 --> Severity: Notice  --> Undefined variable: tmapproved C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\offers.php 56
ERROR - 2025-04-23 06:09:15 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-23 06:11:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 06:11:26 --> Severity: Notice  --> Undefined variable: tpending C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\offers.php 48
ERROR - 2025-04-23 06:11:26 --> Severity: Notice  --> Undefined variable: tmapproved C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\offers.php 57
ERROR - 2025-04-23 06:11:26 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-23 06:11:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 06:11:40 --> Severity: Notice  --> Undefined variable: tpending C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\offers.php 48
ERROR - 2025-04-23 06:11:40 --> Severity: Notice  --> Undefined variable: tmapproved C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\offers.php 57
ERROR - 2025-04-23 06:11:40 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-23 17:52:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 17:52:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 17:52:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 17:53:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 17:53:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 17:53:06 --> Severity: Notice  --> Undefined property: stdClass::$chatuser C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-23 17:53:06 --> Severity: Notice  --> Undefined property: stdClass::$balance C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-23 17:53:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 17:53:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 17:53:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 93 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 98 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 81 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-23 17:53:11 --> Severity: Notice  --> unserialize(): Error at offset 0 of 66 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:11 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-23 17:53:12 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 17:53:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 17:53:16 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-23 18:06:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 18:06:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 18:06:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 18:06:18 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 18:10:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 18:10:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 18:10:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 18:10:47 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 19:30:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 19:30:10 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-23 19:30:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 19:30:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 19:30:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 19:30:19 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-23 19:30:19 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-23 19:30:19 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-23 19:30:19 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-23 21:24:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:24:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:24:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:24:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:24:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:24:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:24:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:24:36 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\wwaff\application\views\admin\content\tracklink_list.php 33
ERROR - 2025-04-23 21:24:36 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 21:24:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 21:24:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:24:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:24:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:25:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:25:31 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\wwaff\application\views\admin\content\tracklink_list.php 33
ERROR - 2025-04-23 21:25:31 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 21:25:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 21:25:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:25:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:25:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:25:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:25:34 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 21:25:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 21:25:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:25:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:25:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:25:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:25:38 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 273
ERROR - 2025-04-23 21:25:38 --> Severity: Notice  --> Undefined variable: manager_join C:\xampp\htdocs\wwaff\application\modules\proxy_report\controllers\proxy_report.php 281
ERROR - 2025-04-23 21:25:38 --> Severity: Notice  --> Undefined variable: userData C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 21:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\admin\index.php 46
ERROR - 2025-04-23 21:25:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:25:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-23 21:25:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
