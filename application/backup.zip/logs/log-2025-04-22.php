ERROR - 2025-04-22 19:31:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 19:31:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 19:31:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 19:32:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 19:32:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 19:32:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:03:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:03:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:03:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:03:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:03:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:03:41 --> Severity: Notice  --> Undefined property: stdClass::$chatuser C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:03:41 --> Severity: Notice  --> Undefined property: stdClass::$balance C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:03:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:03:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:03:45 --> Severity: Notice  --> Undefined property: stdClass::$chatuser C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:03:45 --> Severity: Notice  --> Undefined property: stdClass::$balance C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:03:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:03:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:03:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:03:54 --> Severity: Notice  --> Undefined property: stdClass::$chatuser C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:03:54 --> Severity: Notice  --> Undefined property: stdClass::$balance C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:04:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:04:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:04:11 --> Severity: Notice  --> Undefined property: stdClass::$chatuser C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:04:11 --> Severity: Notice  --> Undefined property: stdClass::$balance C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:04:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:04:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:04:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-22 21:04:14 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 93 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 98 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 81 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> unserialize(): Error at offset 0 of 66 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:04:15 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-22 21:09:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:09:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:09:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:09:37 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-22 21:09:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:09:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\controllers\statistics.php 368
ERROR - 2025-04-22 21:09:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\controllers\statistics.php 371
ERROR - 2025-04-22 21:09:49 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-22 21:09:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:09:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:09:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 168
ERROR - 2025-04-22 21:10:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:10:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:10:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:10:53 --> Severity: Notice  --> Undefined variable: soffer C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 20
ERROR - 2025-04-22 21:10:53 --> Severity: Notice  --> Undefined variable: os_name C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 38
ERROR - 2025-04-22 21:10:53 --> Severity: Notice  --> Undefined variable: country C:\xampp\htdocs\wwaff\application\modules\members\views\statistics\filter.php 56
ERROR - 2025-04-22 21:10:53 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-22 21:11:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:12:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:12:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:12:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\controllers\statistics.php 368
ERROR - 2025-04-22 21:12:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\controllers\statistics.php 371
ERROR - 2025-04-22 21:12:51 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-22 21:12:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:12:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:12:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 168
ERROR - 2025-04-22 21:14:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:14:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:15:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:15:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:15:13 --> Severity: Notice  --> Undefined property: stdClass::$chatuser C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:15:13 --> Severity: Notice  --> Undefined property: stdClass::$balance C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:15:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:15:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:15:37 --> Severity: Notice  --> Undefined property: stdClass::$chatuser C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:15:37 --> Severity: Notice  --> Undefined property: stdClass::$balance C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:15:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:15:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:15:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:41 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:41 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-22 21:15:41 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:15:41 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:15:41 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:41 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:41 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:41 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:15:41 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:15:41 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:15:41 --> Severity: Notice  --> unserialize(): Error at offset 0 of 93 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:41 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 98 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 81 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> unserialize(): Error at offset 0 of 66 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:15:42 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-22 21:16:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:16:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\controllers\statistics.php 368
ERROR - 2025-04-22 21:16:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\controllers\statistics.php 371
ERROR - 2025-04-22 21:16:46 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-22 21:16:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:16:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:16:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 168
ERROR - 2025-04-22 21:19:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:19:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:19:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:19:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:20:00 --> Severity: Notice  --> Undefined property: Advertiser::$get_account_fields C:\xampp\htdocs\wwaff\application\libraries\modules\traits\generic_trait.php 19
ERROR - 2025-04-22 21:20:05 --> Severity: Notice  --> Undefined property: stdClass::$chatuser C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:20:05 --> Severity: Notice  --> Undefined property: stdClass::$balance C:\xampp\htdocs\wwaff\application\modules\members\controllers\auth.php 160
ERROR - 2025-04-22 21:20:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:20:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:20:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 14
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 15
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 16
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 17
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 21
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 27
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 28
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 54
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 57
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 58
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 60
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 87
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 92
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 104
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 105
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 129
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 139
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 150
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 160
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 165
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 170
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 171
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 172
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: offer C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 173
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: t C:\xampp\htdocs\wwaff\application\modules\advertiser\views\offers\campaign_view.php 182
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 177
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: hear_about C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 200
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 204
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: aff_type C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 64
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: volume C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 65
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: website C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 67
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\modules\advertiser\views\publishers\campaign_view.php 73
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 93 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 96 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> unserialize(): Error at offset 0 of 60 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:20:09 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:20:09 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:20:10 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:20:10 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:20:10 --> Severity: Notice  --> unserialize(): Error at offset 0 of 92 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:20:10 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:20:10 --> Severity: Notice  --> unserialize(): Error at offset 0 of 98 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:20:10 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:20:10 --> Severity: Notice  --> unserialize(): Error at offset 0 of 81 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:20:10 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 169
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 170
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 172
ERROR - 2025-04-22 21:20:10 --> Severity: Notice  --> Undefined variable: p C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 188
ERROR - 2025-04-22 21:20:10 --> Severity: Notice  --> unserialize(): Error at offset 0 of 66 bytes C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:10 --> Severity: Warning  --> join(): Invalid arguments passed C:\xampp\htdocs\wwaff\application\modules\advertiser\views\dashboard\vdashboard.php 201
ERROR - 2025-04-22 21:20:10 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-22 21:21:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\controllers\statistics.php 368
ERROR - 2025-04-22 21:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\modules\members\controllers\statistics.php 371
ERROR - 2025-04-22 21:21:22 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-22 21:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 168
ERROR - 2025-04-22 21:22:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:22:09 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-22 21:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 168
ERROR - 2025-04-22 21:25:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:25:55 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-22 21:25:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:25:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:25:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 168
ERROR - 2025-04-22 21:26:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:26:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:26:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:26:03 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-22 21:28:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:28:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:28:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:28:18 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-22 21:29:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:29:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:29:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:29:46 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-22 21:31:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:31:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:31:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:31:25 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-22 21:31:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:31:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:31:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:31:39 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-22 21:31:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:31:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:31:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:31:56 --> Severity: Notice  --> Undefined property: stdClass::$ref_pub_token C:\xampp\htdocs\wwaff\application\modules\advertiser\views\default\vindex.php 145
ERROR - 2025-04-22 21:33:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:33:51 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-22 21:33:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:33:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 96
ERROR - 2025-04-22 21:33:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wwaff\application\views\default\vindex.php 168
ERROR - 2025-04-22 21:34:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:34:34 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-22 21:34:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:34:39 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
ERROR - 2025-04-22 21:34:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\wwaff\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2025-04-22 21:35:25 --> Severity: Notice  --> Undefined index: avartar C:\xampp\htdocs\wwaff\application\views\default\vindex.php 88
