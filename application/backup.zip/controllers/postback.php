<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Postback extends CI_Controller{    	
    function __construct(){
		parent::__construct();	
        parse_str(substr(strrchr($_SERVER['REQUEST_URI'], "?"), 1), $_GET);	
        $this->base_key =$this->config->item('base_key');
        //$this->admin_edit = $this->memcache->get($this->base_key.'_offer_admin_edit');     
        $this->redis = new Redis(); 
        $this->redis->connect('127.0.0.1', 6379); 
    }   
    function testpb(){
        echo 'hello testpb';
    }
    function index(){
        echo 'helloo';
    }	
    function curlip($url){
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_URL,$url);
        $result = curl_exec($ch);  // grab URL and pass it to the variable.
        curl_close($ch);
        return $result;
    }
    function banner($idpb=0,$password=''){//postback với từng con off     
       
        if(!is_numeric($idpb)){$idpb=0;}
        $this->db->select('pb_value,id,title');
        $network=$this->Home_model->get_one('network',array('id'=>$idpb,'pb_pass'=>$password));      
        if(!empty($network)){//đúng pas và id pótback            
            $pb_value_array= unserialize($network->pb_value);//mang du lieu de get             
            $tracklink=$this->input->get_post($pb_value_array['clickid'][0], TRUE); //->chinh la id_track
            $sale_amount=$this->input->get_post($pb_value_array['sale_amount'][0], TRUE); //->chinh la id_track
            if($tracklink){           
                //tesst postback adv
                if(strpos($tracklink,'dvTest')){
                 
                   $adv_id = 0;
                   $adv = explode('_',$tracklink);
                   if(!empty($adv[1]))$adv_id = $adv[1];
                   $commission = $this->input->get_post($pb_value_array['commission'][0], TRUE); 
                   $this->db->insert('adv_postback_log',array(
                       'tracklink' =>$adv_id,
                       'finalurl'=>'Adv Test Postback',
                       'response'=>'Comission:' .$commission,                       
                       'userids'=>$adv_id,
                       'campaignid'=>0,
                   ));
                   echo 1;
                   return;
               }
            }
            //lay point tuef net
            if (!empty($pb_value_array['commission'][0])) {
                $point_net = (double)$this->input->get_post($pb_value_array['commission'][0], true); 
            } 
           
            echo $this->postbackAction($tracklink,$point_net,false,$sale_amount);
                      
        }
    }
    function pushConversion(){       
        if(!($this->session->userdata('admin')) &&  ($this->session->userdata('role') != 2)){           
            echo 'You need permission to perform this action!';
            exit();
        }else{
            $data = $this->input->Post('data');
            if(!empty($data)){
                foreach($data as $leadData){
                    $this->postbackAction((int)$leadData['trackId'],(double)$leadData['amount2'],true);
                }
            }
        }
    }
    public function apiPostback($tracklink,$point_net=0,$lead_amount=0){       
  
        $point_net = (double)$point_net; 
        $this->postbackAction($tracklink,$point_net,true,$lead_amount);                      
       
    }
    private function postbackAction($tracklink,$point_net,$isAdv=false,$lead_amount=0){
        if($tracklink){
            //dah cho net adwork tru tien Lead Status: 1 (credited leads) or 2 (reversed leads)//http://www.mysite.com/postback.php?campaign_id=[INFO]&campaign_name=[INFO]&sid=[INFO]&sid2=[INFO]&sid3=[INFO]&status=1&commission=[INFO]&ip=[INFO]&leadID=[INFO]
          
            //get du lieu ca 3 bang user offer va tracking  
            //**********************************************************
            //***************************************************->
            // get     dislead ở bảng user          
            //như vậy cần get ofer.percent và smartlink,type, smartlink.percent
           $qr ="
               SELECT cpalead_tracklink.*,cpalead_offer.percent as offpercent,cpalead_users.dislead 
               FROM cpalead_tracklink
               LEFT JOIN cpalead_users ON cpalead_users.id = cpalead_tracklink.userid
               LEFT JOIN cpalead_offer ON cpalead_offer.id = cpalead_tracklink.offerid
               WHERE cpalead_tracklink.id = $tracklink AND cpalead_tracklink.flead =0 AND cpalead_tracklink.status=0
           ";
           $track = $this->db->query($qr)->row();
           if(!empty($track)){ 
               
               if($this->disLead($track)==1){                  
                   return 1;
               }
               //point_net laf point tra tu net ve
               $point = 0;
               //fix cái amount2 này để nhầm lưu data vào amount 2 cho chuẩn phần hiển thị
               if($isAdv){
                //adv điền bao nhiêu nhận bấy nhiêu. nếu k điền thì nhận theo trong amout2
                    $point = $point_net>0?$point_net:$track->amount2; 
               }else{
                    if($track->amount2>0){
                        $point=$track->amount2;
                    }else{                        
                        //kieemr tra xem dang naof
                        $point = round($point_net*$track->offpercent/100,2); 
                    }
               }
                
                $this->db->where('id',$tracklink);
                if($point!=0){
                   $this->db->update('tracklink',array('amount'=>$point,'lead_amount'=>$lead_amount,'amount2'=>$point,'flead'=>1,'status'=>1));
                }else{
                   $this->db->update('tracklink',array('amount'=>$point,'lead_amount'=>$lead_amount,'flead'=>1,'status'=>1));
                }
                
                if($this->db->affected_rows()>0){      //update thành công-- tránh lead trùng

                   //update cái check proxy sau. vì update trên sẽ bị hen xưiz là thành duplicate postback
                   //$user_agent = $_SERVER['HTTP_USER_AGENT']; 
                   //$user_language = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
                   //$strictness = (int)file_get_contents('setting_file/strictness.txt');
                   //$strictness = 0; // 0 (light) -> 3 (strict)

                   /*
                   $json_result = $this->checkProxy($track->ip, $track->useragent, $track->user_language, $strictness);
                   // Decode the result into an array.
                   $result = json_decode($json_result, true);
                   $fraud_score  = $proxy = '0';
                   
                   if($result['success'] == true) {
                       if($result['fraud_score'])$fraud_score = $result['fraud_score'];
                       if($result['proxy'])$proxy = $result['proxy'];
                           
                   }
                   $this->db->where('id',$tracklink);
                   $this->db->update('tracklink',array('fraud_score'=>$fraud_score,'proxy'=>$proxy));
                   */

                   //xử lý thêm point-report          
                   $this->db->where('id', $track->userid)            
                   ->set('curent', "curent +$point", FALSE)
                   ->set('balance', "balance +$point", FALSE)
                   ->update('users');
               
                   // add vao report
                   $this->db->where( array('id'=>$track->offerid))
                       ->set('lead','lead+1',false)
                       ->set('revenue',"revenue+$point",false)                       
                       ->update('offer');
                   
                   //chay link postback cua mem                    
                  $this->sendPubPostback($track,$point,$lead_amount);
                   
                }
                
              
               return 1;
                
           }else{
                return 0;
           }
       }  
    }
    private function disLead($track){
        //chặn lead 
        $key = $this->base_key.'-'.$track->offerid;     
        $tlead_key = $key.'-tlead';
        $ct = $this->redis->INCR($tlead_key."-".$track->userid,1); 
        $dislead =$track->dislead;
        $mchan = array();
        if($dislead >=1 ){
            //xử lý chặn lead
            $ttc = round(100/$dislead,1);
            $j=0;
            for($i=0;$i<100;$i++){
                $j=$j+1;
                if($j>=$ttc){
                    $mchan[] = $i;
                    //echo $i.'<br>';
                    $j = $j-$ttc;
                    
                }
            }

        }        
        if(in_array($ct,$mchan)){           
            return 1;
        }                         
                
        if($ct >=100){
            $this->redis->INCR($tlead_key."-".$track->userid,-99);
        } 
        return 0;                       
        //end chặn lead
    }
    private function sendPubPostback($track,$point=0,$lead_amount=0){
        $pb= $this->Home_model->get_data('postback',array('affid'=>$track->userid));
        if($pb){
            foreach($pb as $pb){                                
                $url = $pb->postback;

                if(strpos($url,'{sum}')){
                    //
                    $url = str_replace('{sum}',$point,$url);
                }
                if(strpos($url,'{payout}')){
                    //
                    $url = str_replace('{payout}',$point,$url);
                }
                if(strpos($url,'{commission}')){
                    //
                    $url = str_replace('{commission}',$point,$url);
                }
                if(strpos($url,'{sale_amount}')){
                    $url = str_replace('{sale_amount}',$lead_amount,$url);
                }
                if(strpos($url,'{offerid}')){
                    //
                    $url = str_replace('{offerid}',rawurlencode($track->offerid),$url);
                }
                if(strpos($url,'{view}')){
                    //
                    $url = str_replace('{view}',$track->s1,$url);
                } 
                
                if(strpos($url,'{view2}')){
                    //
                    $url = str_replace('{view2}',$track->s2,$url);
                }

                if(strpos($url,'{view3}')){
                    //
                    $url = str_replace('{view3}',$track->s3,$url);
                }
                if(strpos($url,'{view4}')){
                    //
                    $url = str_replace('{view4}',$track->s4,$url);
                }
                if(strpos($url,'{view5}')){
                    //
                    $url = str_replace('{view5}',$track->s5,$url);
                }
                if(strpos($url,'{view6}')){
                    //
                    $url = str_replace('{view6}',$track->s6,$url);
                }
                                        
                
                $resutl = $this->curl_senpost($url);                            
            //end xưr ly  thêm point report
            
            //chèn vào log postback
            $this->db->insert('postback_log',array(
                'finalurl'=>$url,
                'response'=>$resutl,
                'tracklink'=>$track->id,
                'userids'=>$track->userid,
                'campaignid'=>$track->offerid
            ));
            }
        }else{
            $url =$resutl= 'Not Postback URL';
            $this->db->insert('postback_log',array(
                'finalurl'=>$url,
                'response'=>$resutl,
                'tracklink'=>$track->id,
                'userids'=>$track->userid,
                'campaignid'=>$track->offerid
            ));
        }
    }
    function checkProxy($ip, $user_agent, $user_language, $strictness) {
        // Your API Key
        $key = '56b4f42494b6455d97fce1b5bac29f85';

        // Create parameters array
        $parameters = array(
                'key' => $key,
                'ip'	=> $ip,
                'user_agent' => $user_agent,
                'user_language' => $user_language,
                'strictness' => $strictness
        );

        // Format Params
        $formatted_parameters = http_build_query($parameters);

        // Create API Call URL
        $url = sprintf(
                'https://network.affmine.com/api/proxy/proxy_lookup.php?%s', 
                $formatted_parameters
        );


        $timeout = 5;

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, $timeout);

        $json = curl_exec($curl);
        curl_close($curl);

        return $json;
}
    function curl_senpost($url){
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_URL,$url);
        $result = curl_exec($ch);  // grab URL and pass it to the variable.
        curl_close($ch);
        return $result;
    }
    
    function debug(){
        //if($_POST){$vv=serialize($_POST);}else $vv='-get-';
        //$uri = $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"].'--'.$vv;        
        //$this->db->insert('debug',array('debug1'=>$uri)); 
          
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */