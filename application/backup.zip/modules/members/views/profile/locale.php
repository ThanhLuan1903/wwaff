<div class="_3vMlZCRTDMcko6fQUVb1Uf css-1qvl0ud css-y2hsyn tabcontent locale">
   <form class="sc-hycgNl hCPKEY">
      <div>
         <p class="sc-dTLGrV kokyiS">Interface language</p>
         <div class="_2pOF-T29kOhb_V7rdJc7lm">
            <div class="_19C74tkRgpO1m06ZW7AnB1 css-d3aal9">
               <div class="_2OwLpj9TZ-8y_zCUI9GiK5">
                  <div class="_3XLJyNAzVNxxfc02Pjj2fW">
                     <span class="_3aNWr-_oGR2IfWm2Dgv-87">English</span>
                     <div class="_2MwchzF2ZswCEBEcL8RjRk"></div>
                  </div>
               </div>
               <div class="hwGe6ChZS1mygU7IkVQkN ueyjmSYC7EYpmNEMn2w2M">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="_6FF2NYn2DKbXwyhEkUyVK">
                     <polyline points="6 9 12 15 18 9"></polyline>
                  </svg>
               </div>
            </div>
         </div>
      </div>
      <div class="sc-chAAoq icYlHL">
         <p class="sc-dTLGrV kokyiS">Timezone</p>
         <div class="_2pOF-T29kOhb_V7rdJc7lm">
            <div class="_19C74tkRgpO1m06ZW7AnB1 css-d3aal9">
               <div class="_2OwLpj9TZ-8y_zCUI9GiK5">
                  <div class="_3XLJyNAzVNxxfc02Pjj2fW">
                     <span class="_3aNWr-_oGR2IfWm2Dgv-87">UTC (UTC+00:00)</span>
                     <div class="_2MwchzF2ZswCEBEcL8RjRk"></div>
                  </div>
               </div>
               <div class="hwGe6ChZS1mygU7IkVQkN ueyjmSYC7EYpmNEMn2w2M">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="_6FF2NYn2DKbXwyhEkUyVK">
                     <polyline points="6 9 12 15 18 9"></polyline>
                  </svg>
               </div>
            </div>
         </div>
      </div>
      <div>
      <button class="data_save K3TX2EnGEDIGIEiEIo_0X _3-Xcfgk4YnBeM0kgvmZfs_">
                     <div class="_3kiCWIsiMrRqCXneU8Asq6" style="height: 0px; width: 0px; left: 0px; top: 0px;"></div>
                     <span class="_1pFgCebzxXEI3gItBe_863">
                        <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="">
                           <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                           <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                        </svg>
                     </span>
                     <span class="_3axrJUuPR6Tfk-J1aQF4dm">Save</span>
                  </button>
      </div>
   </form>
</div>