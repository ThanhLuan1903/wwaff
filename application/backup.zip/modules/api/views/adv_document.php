<script type="text/javascript">
$(document).ready(function() {

    $('#copy_button').click(function() {
        $('.chidden').show();
        var clipboardValue = $('#json_link')[0].href;
        var aux = document.createElement("input");
        aux.setAttribute("value", clipboardValue);
        document.body.appendChild(aux);
        aux.select();
        document.execCommand("copy");
        document.body.removeChild(aux);
        $('.chidden').hide();
        $('.thongbao').text('Coppied !');
    });
    //updateFeedLink($("#pubkey_radio"));

});
</script>
<style>
h1 {
    font-size: 2rem;
}

h2 {
    font-size: 1.5rem;
}

h3 {
    font-size: 1.25rem;
}

.container {
    background-color: #e9ecef;
    border: 1px solid #ced4da;
    border-radius: 5px;
    padding: 20px;
    margin-bottom: 20px
}
</style>
<div class="container mt-5">
    <h1 class="mb-4">API Documentation for Advertisers</h1>

    <h2>Overview</h2>
    <p>This API allows advertisers to post conversion or lead
        information to our network. To use the API, you need to include
        an API key in the URL as a GET parameter and adhere to the data
        format we require.</p>

    <h2>Endpoint URL</h2>

    <?php      
        
         $aplink = base_url('api/adv/conversions?apikey=YOURAPIKEY');
         ?>

    <pre
        class="bg-light p-3 rounded"><code><span class="badge bg-success">POST</span> <?php echo $aplink;?></a></code></pre>



    <h2>Conversion/Lead Information</h2>

    <h3>Data Format</h3>
    <p>The data should be sent in JSON format with the following
        fields:</p>
    <ul>       
        <li><code>click_id</code>: The click ID provided at the time of the click.</li>
        <li><code>commission</code>: The commission amount for the conversion.</li>
        <li><code>sale_amount</code>: The sale amount for the conversion.</li>
    </ul>

    <h3>Request Example</h3>
    <pre class="bg-light p-3 rounded">
        <code>
            {           
            "click_id": "12345",
            "commission": 50.00,
            "sale_amount": 500.00
            }
        </code>
    </pre>
    <h3>Response</h3>
    <p>If the request is successfully processed, the API will return an
        HTTP status code of 200 and a confirmation message.</p>

    <h3>Response Example</h3>
    <pre class="bg-light p-3 rounded">
        <code>
            {
                "status": "success",
                "message": "Conversion recorded successfully"
            }
        </code>
    </pre>

    <h2>Status Codes</h2>
    <ul>
        <li><code>200 OK</code>: The request was successful.</li>
        <li><code>400 Bad Request</code>: The request is invalid
            (missing or incorrectly formatted data).</li>
        <li><code>401 Unauthorized</code>: Access is denied (invalid API
            key).</li>
        <li><code>500 Internal Server Error</code>: System error.</li>
    </ul>



            <!--code>
            Array
            (
                [status] => success
                [data] => Array
                    (
                        [0] => stdClass Object
                            (
                                [id] => 4561985
                                [userid] => 2593
                                [offerid] => 16496
                                [ip] => 2401:d800:b7f3:30a:d84b:6662:5e03:c7ba
                                [date] => 2024-07-11 22:32:13
                                [s1] => 0
                                [s2] => 0
                                [oname] => Đào Ngâm
                                [flead] => 1
                                [status] => 1
                                [amount] => 10.00
                                [amount2] => 0.00
                                [amount3] => 0
                                [useragent] => Mozilla/5.0 (iPhone; CPU iPhone OS 17_0_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0.1 Mobile/15E148 Safari/604.1
                                [idnet] => 266
                                [s] => 
                                [s3] => 0
                                [s4] => 0
                                [s5] => 0
                                [s6] => 0
                                [browser] => Safari
                                [os_name] => iOS
                                [device_type] => mobile
                                [device_manuf] => Apple
                                [device_model] => iPhone
                                [countries] => VN
                                [cities] => 
                                [fraud_score] => 0
                                [proxy] => 0
                                [user_language] => en-GB,en-US;q=0.9,en;q=0.8
                                [smartlink] => 0
                                [smartoff] => 0
                                [deadline] => 
                                [traffic_source] => Google Organic
                                [lead_date] => 
                                [click_date] => 
                                [commission] => 
                                [producer_id] => 
                                [keyword_search] => 
                                [product] => 
                                [search_engine] => 
                                [lead_amount] => 
                                [click_url] => 
                                [producer_currency] => USD
                                [duplicate_ip] => 1
                                [duplicate_device] => 1
                                [diff_language] => 1
                            )

                    )

            )
            </code-->
    <h2>Support Contact</h2>
    <p>If you encounter any issues while using the API, please contact
        us at <a href="mailto:support@wwaff.com">support@wwaff.com</a>
        or call +84-123-456-789.</p>
</div>